package com.example.vales_ifthen;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnDecision1 = findViewById(R.id.btnDecision1);
        Button btnDecision2 = findViewById(R.id.btnDecision2);

        TextView txtLore = findViewById(R.id.txtLore);
        txtLore.setText("The year is 1949. On the aftermath of World War II and the Japanese Empire defeated, China is now once again beset by conflict. After uniting against the foreign invader, the Kuomintang, led by Chiang Kai Shel, and the Communist Party, led by Mao Zedong, immediately resumed the Chinese Civil War for control of the country. Please choose the victor to proceed with the scenario.");

    }
    @Override
    public void onClick(View view) {

        TextView txtAns = findViewById(R.id.txtAns);


        switch (view.getId()) {
            case R.id.btnDecision1:
                txtAns.setText("You have chosen Chiang Kai Shek as the winner of the Chinese Civil War. China will now be known as The Republic of China. The government is now led by the Kuomintang. Your style of governance is now a Single-Party, Right Wing, and Authoritarian. You are now allies with the United States.");
                break;
            case R.id.btnDecision2:
                txtAns.setText("You have chosen Mao Zedong as the winner of the Chinese Civil War. China will now be known as The People's Republic of China. The government is now led by the Communist Party. Your style of governance is now a Single-Party, Left Wing Wing, and Authoritarian. You are now allies with the Soviet Union.");
                break;


        }
    }
}
